
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
	
		try {
			MenuPane mainMenu = new MenuPane();
			final Scene menuScene = new Scene(mainMenu,250,300);
			
			Register register = new Register();
			Scene registerScene = new Scene(register);
			
			Points points = new Points();
			Login login = new Login(points);
			Scene loginScene = new Scene(login);
			
			register.buttonBack.setOnAction((event)->{
				primaryStage.setScene(menuScene);
			});

			mainMenu.btnRegister.setOnAction((event)->{
				primaryStage.setScene(registerScene);
			});
			
			login.buttonBack.setOnAction((event)->{
				primaryStage.setScene(menuScene);
			});
			
			mainMenu.btnLogin.setOnAction((event)->{
				primaryStage.setScene(loginScene);
			});

			Info info = new Info();
			Scene infoScene = new Scene(info);
			
			mainMenu.btnInfo.setOnAction((event)->{
				primaryStage.setScene(infoScene);
			});
			
			info.buttonBack.setOnAction((event)->{
				primaryStage.setScene(menuScene);
			});
			
			Menu orderMenu = new Menu(300,250, points, primaryStage, ()-> {
				primaryStage.setScene(menuScene);
			});

			Scene orderScene = new Scene(orderMenu);
			mainMenu.btnOrder.setOnAction((event) -> {
				primaryStage.setScene(orderScene);
			});

			primaryStage.setScene(menuScene);
			primaryStage.show();
			primaryStage.setTitle("Latte Love Ordering System");
			
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	



	public static void main(String[] args) {
		launch(args);
	}
}
