
public class Points {
	private double points;
	
	public Points() {
		points = 0;
	}

	public double getPoints() {
		return points;
	}

	public void addPoints(double points) {
		this.points += points;
	}
	
	public String displayPoints() {
		return String.format("%d", (int)Math.floor(points));
	}
	
}
