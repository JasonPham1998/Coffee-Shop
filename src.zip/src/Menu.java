import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Menu extends BaseScene {
	
	private final Points points;
	private final Stage primaryStage;
	private final TextArea showTotal;
	private final LineField vanillaLineField;
	private final LineField mochaLineField;
	private final LineField caramelLineField;
	private final LineField hazelnutLineField;
	private final LineField matchaLineField;
	
	private Button back;
	private Button confirm;
	private Button addToCart;
	private Button clearCart;
	private RadioButton credit;
	private RadioButton debit;
	private RadioButton cash;
	private CheckBox yes;
	private Text menu;
	private Label makeCartLabel;
	private TextArea makeCartTxtArea;
	
	private double totalPrice = 0;
	private ToggleGroup RadioGroup;
	
	public Menu(int width, int height, final Points points, final Stage primaryStage,
			GoHomeListener onBackClicked) {
		super(onBackClicked);
		this.primaryStage = primaryStage;
		this.points = points;
		
		makeButtons();
		makeCart();
					
		// Create Row by Row Layout
		Titles titleNames = new Titles();
		this.add(titleNames, 0, 1);
		
		vanillaLineField = new LineField("Vanilla Latte", 3.50);
		this.add(vanillaLineField, 0, 2);
		
		mochaLineField = new LineField("Mocha Latte", 4.00);
		this.add(mochaLineField, 0, 3);
		
		caramelLineField = new LineField("Caramel Latte", 4.25);
		this.add(caramelLineField, 0, 4);
		
		hazelnutLineField = new LineField("Hazelnut Latte", 4.75);
		this.add(hazelnutLineField, 0, 5);
		
		matchaLineField = new LineField("Matcha Latte", 5.25);
		this.add(matchaLineField, 0, 6);
		
		showTotal = new TextArea();
		showTotal.setMaxSize(180, 25);
		showTotal.setEditable(false);
		
		addToCart.setOnAction((event)->{
			String vanillaOrder = vanillaLineField.getQuantity();
			int vanillaAmt = Integer.parseInt(vanillaOrder);
			
			String mochaOrder = mochaLineField.getQuantity();
			int mochaAmt = Integer.parseInt(mochaOrder);
			
			String caramelOrder = caramelLineField.getQuantity();
			int caramelAmt = Integer.parseInt(caramelOrder);
			
			String hazelnutOrder = hazelnutLineField.getQuantity();
			int hazelnutAmt = Integer.parseInt(hazelnutOrder);
			
			String matchaOrder = matchaLineField.getQuantity();
			int matchaAmt = Integer.parseInt(matchaOrder);
	
			
			String tempCart;
			
				getVanillaOrder(vanillaOrder, vanillaAmt);
				getMochaOrder(mochaOrder, mochaAmt);
				getCaramelOrder(caramelOrder, caramelAmt);
				getHazelnutOrder(hazelnutOrder, hazelnutAmt);
				getMatchaOrder(matchaOrder, matchaAmt);
			
			showTotal.setText("");
			String t = String.format("Your total amount is $%.2f", totalPrice);
			showTotal.appendText(t);

		});
		
		setLayout();
	}

	private void getVanillaOrder(String vanillaOrder, int vanillaAmt) {
		String tempCart;
		if (vanillaAmt > 0) {
			double vanillaTotal = vanillaAmt * vanillaLineField.getPrice();
			totalPrice += vanillaTotal;

			tempCart = vanillaOrder + " x " + vanillaLineField.getProductName()
						+ "\n";
			makeCartTxtArea.appendText(tempCart);

			if (vanillaLineField.IsIceChecked() && vanillaLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd ice and sugar\n");
			} else if (vanillaLineField.IsIceChecked() && !vanillaLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd ice\n");
			} else if (!vanillaLineField.IsIceChecked() && vanillaLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd sugar\n");
			}
		}
	}

	private void getCaramelOrder(String caramelOrder, int caramelAmt) {
		String tempCart;
		if (caramelAmt > 0) {
			double caramelTotal = caramelAmt * caramelLineField.getPrice();
			totalPrice += caramelTotal;

			tempCart = caramelOrder + " x " + caramelLineField.getProductName()
						+ "\n";
			makeCartTxtArea.appendText(tempCart);

			if (caramelLineField.IsIceChecked() && caramelLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd ice and sugar\n");
			} else if (caramelLineField.IsIceChecked() && !caramelLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd ice\n");
			} else if (!caramelLineField.IsIceChecked() && caramelLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd sugar\n");
			}
		}
	}

	private void getMochaOrder(String mochaOrder, int mochaAmt) {
		String tempCart;
		if (mochaAmt > 0) {
			double mochaTotal = mochaAmt * mochaLineField.getPrice();
			totalPrice += mochaTotal;

			tempCart = mochaOrder + " x " + mochaLineField.getProductName()
						+ "\n";
			makeCartTxtArea.appendText(tempCart);

			if (mochaLineField.IsIceChecked() && mochaLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd ice and sugar\n");
			} else if (mochaLineField.IsIceChecked() && !mochaLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd ice\n");
			} else if (!mochaLineField.IsIceChecked() && mochaLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd sugar\n");
			}
		}
	}

	private void getHazelnutOrder(String hazelnutOrder, int hazelnutAmt) {
		String tempCart;
		if (hazelnutAmt > 0) {
			double hazelnutTotal = hazelnutAmt * hazelnutLineField.getPrice();
			totalPrice += hazelnutTotal;

			tempCart = hazelnutOrder + " x " + hazelnutLineField.getProductName()
						+ "\n";
			makeCartTxtArea.appendText(tempCart);

			if (hazelnutLineField.IsIceChecked() && hazelnutLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd ice and sugar\n");
			} else if (hazelnutLineField.IsIceChecked() && !hazelnutLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd ice\n");
			} else if (!hazelnutLineField.IsIceChecked() && hazelnutLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd sugar\n");
			}
		}
	}

	private void getMatchaOrder(String matchaOrder, int matchaAmt) {
		String tempCart;
		if (matchaAmt > 0) {
			double matchaTotal = matchaAmt * matchaLineField.getPrice();
			totalPrice += matchaTotal;

			tempCart = matchaOrder + " x " + matchaLineField.getProductName()
						+ "\n";
			makeCartTxtArea.appendText(tempCart);

			if (matchaLineField.IsIceChecked() && matchaLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd ice and sugar\n");
			} else if (matchaLineField.IsIceChecked() && !matchaLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd ice\n");
			} else if (!matchaLineField.IsIceChecked() && matchaLineField.IsSugarChecked()) {
				makeCartTxtArea.appendText("\tAdd sugar\n");
			}
		}
	}

	private void makeCart() {
		makeCartLabel = new Label("Your Cart");
		makeCartTxtArea = new TextArea();
		makeCartTxtArea.setMaxSize(180, 100);
		makeCartTxtArea.setEditable(false);
		makeCartTxtArea.setWrapText(true);
	}

	private void makeButtons() {
		back = new Button("Back Home");
		addToCart = new Button("Add all to Cart");
		clearCart = new Button("Clear Cart");
		confirm = new Button("Confirm");
		yes = new CheckBox("Yes");
		ToggleGroup rg = new ToggleGroup();
		credit = new RadioButton("Credit Card");
		credit.setToggleGroup(rg);
		debit = new RadioButton("Debit Card");
		debit.setToggleGroup(rg);
		cash = new RadioButton("Cash");
		cash.setToggleGroup(rg);
		
		back.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
		addToCart.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
		clearCart.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
		confirm.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
		
		back.setOnAction((event)-> {
			goHomeListener.goHome();

		});
		confirm.setOnAction((event)-> {
			points.addPoints(totalPrice / 10.0);
			
			OrderTime orderTime = new OrderTime(goHomeListener);
			Scene orderScene = new Scene(orderTime);
			primaryStage.setScene(orderScene);
		});
		
		clearCart.setOnAction((event) -> {
			makeCartTxtArea.setText("");
			showTotal.setText("");
			totalPrice = 0;
		});
		
	}

	private void setLayout() {
		this.setStyle("-fx-background-color: Silver;");
		Font font = Font.font("Verdana", FontWeight.BOLD, 24);
		
		menu = new Text("Menu");
		menu.setFont(font);
		this.add(menu, 0, 0);
		this.setPadding(new Insets(10,10,10,10));
		this.setVgap(2);
		menu.setFill(Color.SADDLEBROWN);
		
		final Label pointsLabel = new Label("Join Loyalty Program?");
		final Label payOption = new Label("Pay by:");
		
		this.add(addToCart, 1, 5);
		this.add(clearCart, 1, 6);
		
		this.add(pointsLabel, 1,10);
		this.add(yes, 1, 11);
		this.add(payOption, 1,12);
		this.add(debit, 1, 13);
		this.add(credit, 1, 14);
		this.add(cash, 1, 15);
		
		this.add(confirm, 1, 27);
		this.add(back, 1, 28);
		
		this.add(makeCartLabel, 0, 8);
		
		this.add(makeCartTxtArea, 0, 9, 1, 9);
		this.add(showTotal, 0, 27, 1, 27);
		
	    this.setStyle("-fx-background-color: #e3bc9c; -fx-textfill: white;");  
	}

}


