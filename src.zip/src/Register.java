
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import javafx.scene.text.Text;

public class Register extends GridPane {
	Button buttonBack;
	String nameR;
	String passwordR;
	String s;
	private Button save;
	
	public Register(){
		
		Text lb1= new Text("Name:");
		TextField t1R= new TextField();
		Text lb2= new Text("Password:");
		TextField t2R= new TextField();
		save = new Button("Register");
		TextArea t3A = new TextArea();
		t3A.setMaxSize(200, 5);
		buttonBack = new Button("Back to Main Menu");
		this.setMinSize(300,300);
		this.setPadding(new Insets(10, 10, 10, 10));
		this.setAlignment(Pos.CENTER);
		this.setVgap(5); 
	    this.setHgap(5);
	    this.add(lb1, 0, 0); 
	    this.add(t1R, 1, 0); 
	    this.add(lb2, 0, 1); 
	    this.add(t2R, 1, 1); 
	    this.add(t3A, 0, 2, 3 ,2);
	    this.add(save, 0, 4);
	    this.add(buttonBack, 1, 4);
	    lb1.setStyle("-fx-font: normal 15px 'Verdana' "); 
	    t1R.setStyle("-fx-font: normal 15px 'Verdana' "); 
	    lb2.setStyle("-fx-font: normal 15px 'Verdana' "); 
	    t2R.setStyle("-fx-font: normal 15px 'Verdana' "); 
	    save.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
	    buttonBack.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
	    this.setStyle("-fx-background-color: #e3bc9c; -fx-textfill: white;");  
	    
	    File file = new File("./src/account.txt");
	    
		try {
				Scanner input = new Scanner(file);
				if(input.hasNextLine()) {
					while(input.hasNextLine()) {
				
						String line=input.nextLine();
						if (s==null)
							s=line;
						else
							s+=line;
						s+="\n";
						
					}
				}
				java.io.PrintWriter output = new java.io.PrintWriter(file);
				save.setOnAction((event)->{
					nameR = t1R.getText();
			        passwordR = t2R.getText();
			        if (s!=null)
			        	{output.print(s);}
					output.print(nameR);
					output.print(",");
				    output.print(passwordR);
				    output.print(",");
				    output.print("0");
				    output.close();
				    input.close();
				    t3A.setText("You are now registered!");
					});
				
				
			input.close();
			} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
}		
	


