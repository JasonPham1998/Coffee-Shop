
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;


public class Titles extends GridPane{
	
	public Titles () {
		final Label itemName = new Label("Item");
		final Label priceName = new Label("Price");
		final Label iceName = new Label("Ice");
		final Label sugarName = new Label("Sugar");
		
		this.getRowConstraints().add(new RowConstraints(25));
		this.getColumnConstraints().add(new ColumnConstraints(90));
		this.getColumnConstraints().add(new ColumnConstraints(65));
		this.getColumnConstraints().add(new ColumnConstraints(15));
		this.setHgap(5);
		
		this.add(itemName, 0, 0);
		this.add(priceName, 1, 0);
		this.add(iceName, 3, 0);
		this.add(sugarName, 4, 0);

	}
	
}
