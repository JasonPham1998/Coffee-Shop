


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
 
public class Info extends GridPane {
	String info="We would like every one can get a coffee for everyday easily to relax.";
	String cont="Latte Love\n" + "Address: 1777x Kingsway Street, Vancouver,B.C" +
			"\nPhone: 778-1234-5xxx" + "\nHours: 10Am-9PM From Monday-Saturday";
	Button buttonBack;
	public Info(){
		TextArea textArea = new TextArea();
		textArea.relocate(10,30);
		textArea.setMinSize(50, 100);
		textArea.setEditable(false); // to make it viewable only
		textArea.setFont(Font.font("Verdana"));
		textArea.setStyle("-fx-font: normal 15px 'Verdana' "); 
		textArea.setWrapText(true);
		buttonBack = new Button("Go back to Menu");
		buttonBack.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
		this.add(buttonBack, 0, 2);
		this.setMinSize(25,100);
		this.setPadding(new Insets(10, 10, 10, 10));
		this.setAlignment(Pos.CENTER);
		textArea.appendText(info+"\n"+cont);
		this.getChildren().add(textArea);
	    this.setStyle("-fx-background-color: #e3bc9c; -fx-textfill: white;");  
		}
	}
		