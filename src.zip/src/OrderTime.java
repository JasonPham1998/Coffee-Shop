
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class OrderTime extends GridPane {

	Thread threadClock ;
	boolean done=false;
	Button buttonBack;
	Button estimate;
	private GoHomeListener goHomeListener;
	private TextField txtClock;
	private TextField time;
	
	public OrderTime(GoHomeListener goHomeListener) {
		this.goHomeListener = goHomeListener;
		txtClock = new TextField();
	    txtClock.setMinWidth(10);
	    txtClock.setEditable(false);
	    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
	    LocalDateTime now  ;
	    time = new TextField("Estimated Time: 1 minute");
	    estimate = new Button ("Click to Process Order");
	    makeBackButton();
		this.add(buttonBack, 3, 3);
		this.add(estimate, 2, 3);
	    this.add(time, 2, 2);
	    this.add(txtClock,2,1);
	    this.setMinSize(300,300);
	    this.setPadding(new Insets(10, 10, 10, 10));
		this.setAlignment(Pos.CENTER);
	    this.setStyle("-fx-background-color: #e3bc9c; -fx-textfill: white;"); 
		threadClock = new Thread();
	    threadClock.start();
		now = LocalDateTime.now();
		txtClock.setText(dtf.format(now));
		estimate.setOnAction((event)->{
			countdown();
		});
	}

	private void makeBackButton() {
		buttonBack = new Button("Back to Main Menu");
	    buttonBack.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
	    estimate.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
	    
	    buttonBack.setOnAction((event)-> {
	    	goHomeListener.goHome();
	    });
	}
	
	private void countdown() {
		new Thread(() -> {
			try {
				for(int i = 60; i >= 0; i--) {
					txtClock.setText(i + " seconds remaining");
					Thread.sleep(1000); // 1 second
				}
				time.setText("Your order is complete and ready to pick up!\n"
						+ "Please have your payment ready.");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}).start();
		
	}

}
