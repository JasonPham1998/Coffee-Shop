import javafx.scene.layout.GridPane;

public abstract class BaseScene extends GridPane {
	protected final GoHomeListener goHomeListener;

	BaseScene(final GoHomeListener goHomeListener) {
		this.goHomeListener = goHomeListener;
	}
}
