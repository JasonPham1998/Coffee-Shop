import javafx.application.Platform;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class MenuPane extends Pane {

	Button btnRegister;
	Button btnLogin;
	Button btnInfo;
	Button btnOrder;
	Button btnTime;
	public MenuPane() {
		
		Font font = Font.font("Verdana", FontWeight.BOLD, 24);
		
		Text titleName = new Text("Latte Love");
		titleName.relocate(60,30);
		titleName.setFont(font);
		titleName.setFill(Color.SADDLEBROWN);
		
		btnOrder = new Button("Order");
		btnOrder.relocate(100, 120);
		btnLogin = new Button("Login");
		btnLogin.relocate(70,170);
		btnRegister = new Button("Register");
		btnRegister.relocate(125,170);

		btnInfo = new Button("Contact Info");
		btnInfo.relocate(80,210);

		Button btnExit = new Button("Exit");
		btnExit.relocate(100,250);
		
		btnOrder.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
		btnLogin.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
		btnRegister.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
		btnInfo.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
		btnExit.setStyle("-fx-background-color: #cacaca; -fx-textfill: white;");
		
	    this.setStyle("-fx-background-color: #e3bc9c; -fx-textfill: white;");  
		
		this.getChildren().addAll(titleName,btnRegister,btnLogin,btnInfo,btnOrder,btnExit);
		
		btnExit.setOnAction((event)->{
			Platform.exit();
		});
		
		
	}

}
