import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
 
import javafx.scene.text.Text;

public class Login extends GridPane {
	Button buttonBack;
	String nameL;
	String passwordL;
	String suc="Login Successful";
	String fail="Login Fail. Incorrect username or password.";
	Button pointBtn;
	private Points points;
	
	public Login(final Points points){
		this.points = points;
		Text lb1= new Text("Name:");
		TextField t1= new TextField();
		Text lb2= new Text("Password:");
		TextField t2= new TextField();
		TextArea tArea= new TextArea();
		tArea.setWrapText(true);
		tArea.setPrefHeight(100);  
		tArea.setPrefWidth(300); 
		Button login= new Button("Login");
		buttonBack = new Button("Back to Main Menu");
		pointBtn= new Button("Points");
		this.setMinSize(300,200);
		this.setPadding(new Insets(10, 10, 10, 10));
		this.setAlignment(Pos.CENTER);
		this.setVgap(5); 
	    this.setHgap(5);
	    this.add(lb1, 0, 0); 
	    this.add(t1, 1, 0); 
	    this.add(lb2, 0, 1); 
	    this.add(t2, 1, 1); 
	
	    this.add(login, 0, 2);
	    this.add(buttonBack, 1, 2);
	    this.add(tArea, 1, 4);
	    lb1.setStyle("-fx-font: normal 15px 'Verdana'; "); 
	    t1.setStyle("-fx-font: normal 15px 'Verdana' "); 
	    lb2.setStyle("-fx-font: normal 15px 'Verdana' "); 
	    t2.setStyle("-fx-font: normal 15px 'Verdana' "); 
	    login.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
	    buttonBack.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
	    this.setStyle("-fx-background-color: #e3bc9c; -fx-textfill: white;"); 
	    this.add(pointBtn, 2, 2);
	    pointBtn.setStyle("-fx-background-color: #f2e7e2; -fx-textfill: white;");
	    File file = new File("./src/account.txt");
	    login.setOnAction((event)->{
	    	nameL=t1.getText();
	    	passwordL=t2.getText();
	    	try {
				Scanner sc= new Scanner(file);
				boolean isSuccessful = false;
				while (sc.hasNextLine()) {
					String s= sc.nextLine();
					String Array[]= s.split(",");
					if (Array[0].equals(nameL) && Array[1].equals(passwordL)) {
						isSuccessful = true;
						break;
					}
				}

				sc.close();
				
				if(!isSuccessful) {
					tArea.setText(fail);
				} else {
					tArea.setText(suc);
					tArea.appendText("\nClick the button Point if you want to check the points.");
				}
				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
	    });
	    pointBtn.setOnAction((event)->{
			tArea.appendText("\n"+"This is your points: "+ points.displayPoints() +"\n"+" You need"
					 +" 50 points to earn a free drink");
		});
		
					
		}

	}
		
	


