
interface GoHomeListener {
	void goHome();
}