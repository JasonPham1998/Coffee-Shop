

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;

public class LineField extends GridPane{
	private final Label productNameLabel;
	private final Label priceLabel;
	private final TextField quantityTextField;
	private final CheckBox hasIceCheckBox;
	private final CheckBox hasSugarCheckBox;
	private final double price;
	
	public LineField (String productName, double price) {
		this.price = price;
		
		productNameLabel = new Label(productName);
		productNameLabel.setMaxSize(200,10);
		
		priceLabel = new Label(String.format("$%.2f", price));
		
		quantityTextField = new TextField();
		quantityTextField.setMaxSize(50, 10);
		quantityTextField.setText("0");
		hasIceCheckBox = new CheckBox();
		hasSugarCheckBox = new CheckBox();
		
		this.getRowConstraints().add(new RowConstraints(25));
		this.getColumnConstraints().add(new ColumnConstraints(95));
		this.setHgap(5);
		
		this.add(productNameLabel, 0, 0);
		this.add(priceLabel, 1, 0);
		this.add(quantityTextField, 2, 0);
		this.add(hasIceCheckBox, 3, 0);
		this.add(hasSugarCheckBox, 4, 0);
	}
	
	public String getProductName() {
		return productNameLabel.getText();
	}
	
	public double getPrice() {
		return price;
	}
	
	public String getQuantity() {
		return quantityTextField.getText();
	}
	
	public boolean IsIceChecked() {
		return hasIceCheckBox.isSelected();
	}
	
	public boolean IsSugarChecked() {
		return hasSugarCheckBox.isSelected();
	}
	
}
